# PSL (IEEE 1850) Syntax — VS Code starter

A TextMate grammar for IEEE 1850 Property Specification Language. Two modes:

1. **Standalone** — `.psl` and `.vunit` files are highlighted directly.
2. **Injected into VHDL** — inside any file VS Code recognises as VHDL (`source.vhdl`, registered by VHDL-LS / `hbohlin.vhdl-ls`), both `-- psl …` line comments and VHDL-2008 `/* psl … */` block comments are re-tokenized as PSL while ordinary VHDL comments stay vanilla.

## What gets highlighted

- **Verification directives** — `assert`, `assume`, `cover`, `restrict`, `fairness`, `strong`, plus `*_guarantee` variants
- **Directive labels** — `name : assert …` / `name : assume …` etc. The label gets `entity.name.label.psl`, the colon gets its own punctuation scope
- **Verification units** — `vunit` / `vmode` / `vprop` declarations; the unit's name is highlighted distinctly via `entity.name.section.psl`
- **Property and sequence declarations** — `property name is …` / `sequence name (args) is …`; the declared name gets `entity.name.function.psl`
- **`default clock`** declarations
- **FL temporal operators** — `always`, `never`, `eventually!`, the full `next` family (`next!`, `next_a`, `next_e`, `next_event_a!`, …), `until` and `before` families, plus `abort` / `async_abort` / `sync_abort`. All tagged `keyword.control.*` so themes paint them visibly
- **SERE brackets** — `[*]`, `[+]`, `[*n]`, `[*n:m]`, `[*n:inf]`, `[=n]`, `[->n]`
- **SERE composition** — `;` `:` `|` `&&` and `within`
- **Implication arrows** — `|->`, `|=>`, `->`, `<->`
- **Logical operators** — `and`, `or`, `not`, `xor`, `nand`, `nor`, `xnor`
- **PSL built-in functions** — `prev`, `stable`, `rose`, `fell`, `ended`, `nondet`, `nondet_vector`, `onehot`, `onehot0`, `isunknown`, `countones`
- **Common VHDL helper functions** — `rising_edge`, `falling_edge`, `to_unsigned`, `to_integer`, `unsigned`, `signed`, `to_signed`, `resize`, `shift_left`, `shift_right`
- **Types** — `boolean`, `bit`, `bitvector`, `numeric`, `string`, `integer`, `real`
- **Numbers** — decimal, based (`16#FF#`), bit-string literals (`b"1010"`, `x"FF"`)
- **Character literals** — single-char VHDL constants like `'0'`, `'1'`, `'X'`, `'Z'`, `'-'`

## Install (local, no marketplace publish)

Drop the whole `psl-vscode` folder into your user extensions directory:

| OS              | Path                                          |
|-----------------|-----------------------------------------------|
| Linux / macOS   | `~/.vscode/extensions/psl-vscode/`            |
| Windows         | `%USERPROFILE%\.vscode\extensions\psl-vscode\` |

Then reload VS Code (`Ctrl+Shift+P` → *Developer: Reload Window*). Open `example.psl` for the standalone view and `example.vhd` to see both injection forms (line and block) side-by-side with vanilla VHDL comments.

## How the VHDL injection works

`syntaxes/psl-injection-vhdl.tmLanguage.json` declares `injectTo: ["source.vhdl"]` and uses `injectionSelector: "L:source.vhdl"`. The `L:` ("left", high-priority) prefix lets the injection's tokens win over VHDL-LS's host comment grammar inside `-- psl …` and `/* psl … */` regions. Both forms share a single `psl-body` repository entry that pulls every pattern from the standalone grammar via `include: "source.psl#…"`, so a fix to one mode automatically applies to the other.

### Limitations

- **Multi-line directives in `--` form.** A bare `-- psl` line is highlighted from marker to end-of-line; if a directive's expression continues on subsequent `--` lines without repeating the `psl` marker, those continuation lines stay vanilla-comment-coloured. The block form (`/* psl … */`) handles multi-line cleanly and is preferred for anything beyond a single line, if your VHDL toolchain accepts VHDL-2008 block comments.
- **No semantic checks.** Pure regex tokenization. `assert` written as a normal identifier inside a `-- psl` region would still be coloured as a directive. Real analysis would need a language server.
- **Heuristic builtin recognition.** `prev`, `stable`, `rose`, etc. are PSL standard-library functions, not reserved keywords; tagging them as `support.function` is a useful overreach but will misfire if you happen to use one of those names as a signal.

## Adapting to other VHDL extensions

If you use a different VHDL extension, check its `package.json` for `scopeName`. Most use `source.vhdl`. Change `injectTo` and `injectionSelector` in the injection grammar to match.

For Verilog / SystemVerilog flavour PSL (using `// psl` and case-sensitive keywords): copy `psl-injection-vhdl.tmLanguage.json` to a Verilog variant, change `injectTo` to `source.verilog` (or `source.systemverilog`), change the line-form `begin` regex to `(?i)(//)\\s*(psl)\\b\\s*`, and consider dropping the `(?i)` from the keyword patterns in the standalone grammar if you want strict case-sensitive matching.

## License

Public domain / CC0 — do whatever.
