-- example.vhd: regular VHDL with embedded PSL directives.
-- Lines starting with '-- psl' should be re-tokenized; ordinary
-- '--' lines should remain plain comment-colored.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity counter is
  port (
    clk   : in  std_logic;
    rst   : in  std_logic;
    en    : in  std_logic;
    count : out std_logic_vector(3 downto 0)
  );
end entity;

architecture rtl of counter is
  signal cnt : unsigned(3 downto 0) := (others => '0');
begin

  -- Plain VHDL comment: should stay vanilla comment-colored.
  -- This one too. Even with words like assert, always, never inside.

  -- psl default clock is rising_edge(clk);

  -- Single-line directives with labels:
  -- psl no_overflow : assert always (cnt < 16) report "overflowed";
  -- psl handshake   : assume always (en -> next_event_a!(rst)(cnt = 0 until! en));
  -- psl burst       : cover  {en; cnt[*4]; not en};

  -- Char literals and builtins inside a -- psl line:
  -- psl reset_clears : assert always (rst = '1' -> next (cnt = "0000"));
  -- psl no_glitch    : assert always (stable(en) until! rose(rst));

  /* psl
       property bounded_inflight is
         always (en -> eventually! (cnt = 15)) abort rst;

       a_bounded : assert bounded_inflight report "never reached max";
   */

  process(clk)
  begin
    if rising_edge(clk) then
      if rst = '1' then
        cnt <= (others => '0');
      elsif en = '1' then
        cnt <= cnt + 1;
      end if;
    end if;
  end process;

  count <= std_logic_vector(cnt);

end architecture;
